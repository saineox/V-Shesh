// var startNumber = 0;
document.getElementsByClassName("result").innerHTML = "output";

const element = document.getElementById("resultid");
// element.innerHTML = "New Heading";
// document.getElementById("resultid").innerHTML = "New Heading";

function addition() {
  var number1 = parseInt(prompt("Enter Number 1"));
  var number2 = parseInt(prompt("Enter Number 2"));
  output = number1 + number2;
  //document.write(number1 + number2);
  //   document.getElementById("resultid").innerHTML= "output";
  element.innerHTML = output;
}

// 2. Read in two numbers and display the larger number.
// 3. Read in two numbers and display them in ascending order.
// 4. Use a loop to display the numbers 0 through 5
function largNumber() {
  var number1 = parseInt(prompt("Enter Number 1"));
  var number2 = parseInt(prompt("Enter Number 2"));
  if (number1 > number2) {
    output = number1;
  } else {
    output = number2;
  }
  element.innerHTML = "Largest number is " + output;
}



function ascendingNumber() {
  var number1 = parseInt(prompt("Enter Number 1"));
  var number2 = parseInt(prompt("Enter Number 2"));
  if (number1 > number2) {
    
      element.innerHTML =number2 +"<br> " + number1;
    } else {
       
        element.innerHTML =number1 +"<br> " + number2;
      }
    }
    
   //Print 1 to 5 woth loop 
    function oneToFive() {
      // alert("Amol is genious")
      var number1 = 0;
      for (var number=1; number < 6; number++){
        console.log("PrintlistOntofive", number)
      number1 = number1 + "<br>" + number ;
      }
      element.innerHTML = number1;

}


//5. Use a loop to display the integers 9 through 0 in descending order.

function nineToZero() {
  // alert("Amol is genious")
  var number1 = 9;
  for (var number=8; number > 0; number--){
    console.log("PrintlistOntofive", number)
    number1 = number1 + "<br>" + number ;
  }
  element.innerHTML = number1;
}

// 6. Use a loop to display the numbers in the range 0…20 that are multiples of 3.












