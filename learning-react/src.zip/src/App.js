import React from "react";
// import App from "./Appx";
import LoginPage from "./component/login";

const App = () => {
  return (
    <div>
      <h1> Welcome to react </h1>
      <LoginPage></LoginPage>
    </div>
  );
};

// function App() {
//   return (
//     <div>
//       <h1>Hello, Welcome to Home Page</h1>
//     </div>
//   );
// }

export default App;
