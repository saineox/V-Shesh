import React from "react";

const InboxPage = () => {

    return (
        <div className="main">
            <h3> InboxPage </h3>
        </div>
    )
}

export default InboxPage;